package com.etcd.nacos.controller;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import io.etcd.jetcd.ByteSequence;
import io.etcd.jetcd.Client;
import io.etcd.jetcd.KeyValue;
import io.etcd.jetcd.kv.PutResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

@RestController
@RequestMapping("nacos/v1/ns")
public class NacosController {
    /**
     *
     * url:?serviceName=automation-user
     * {
     *     "hosts": [
     *         {
     *             "ip": "192.168.4.16",
     *             "port": 9002,
     *             "valid": true,
     *             "healthy": true,
     *             "marked": false,
     *             "instanceId": "192.168.4.16#9002#DEFAULT#DEFAULT_GROUP@@automation-user",
     *             "metadata": {
     *                 "preserved.register.source": "SPRING_CLOUD"
     *             },
     *             "enabled": true,
     *             "weight": 1.0,
     *             "clusterName": "DEFAULT",
     *             "serviceName": "automation-user",
     *             "ephemeral": true
     *         }
     *     ],
     *     "dom": "automation-user",
     *     "name": "DEFAULT_GROUP@@automation-user",
     *     "cacheMillis": 3000,
     *     "lastRefTime": 1611323643322,
     *     "checksum": "b0c5d6845f3c4f1e36ae74e1cc5a7ec7",
     *     "useSpecifiedURL": false,
     *     "clusters": "",
     *     "env": "",
     *     "metadata": {}
     * }
     */

    @GetMapping("instance/list")
    public String list(@RequestParam("serviceName") String serviceName) throws Exception {
        JSONObject result=new JSONObject();
        result.put("dom",serviceName);
        result.put("name","DEFAULT_GROUP@@"+serviceName);
        result.put("cacheMillis",60000);
        result.put("lastRefTime",System.currentTimeMillis());
        result.put("checksum","b0c5d6845f3c4f1e36ae74e1cc5a7ec7");
        result.put("useSpecifiedURL",false);
        result.put("clusters","");
        result.put("env","");
        result.put("metadata",new JSONObject());
        //从etcd中获取
        String value=get(serviceName);
        JSONObject jsonObject=JSONObject.parseObject(value);
        JSONArray ips = jsonObject.getJSONArray("ips");
        JSONArray ports = jsonObject.getJSONArray("ports");
        List<JSONObject> hosts=new ArrayList<>();
        for (int i = 0; i < ips.size(); i++) {
            String ip=ips.getString(i);
            String port=ports.getString(i);

            /**
             *  {
             *      *             "ip": "192.168.4.16",
             *      *             "port": 9002,
             *      *             "valid": true,
             *      *             "healthy": true,
             *      *             "marked": false,
             *      *             "instanceId": "192.168.4.16#9002#DEFAULT#DEFAULT_GROUP@@automation-user",
             *      *             "metadata": {
             *      *                 "preserved.register.source": "SPRING_CLOUD"
             *      *             },
             *      *             "enabled": true,
             *      *             "weight": 1.0,
             *      *             "clusterName": "DEFAULT",
             *      *             "serviceName": "automation-user",
             *      *             "ephemeral": true
             *      *         }
             */
            JSONObject node=new JSONObject();
            node.put("ip",ip);
            node.put("port",port);
            node.put("valid",true);
            node.put("healthy",true);
            node.put("marked",false);
            node.put("instanceId",ip+"#"+port+"#DEFAULT#DEFAULT_GROUP@@"+serviceName);
            JSONObject metadata=new JSONObject();
            metadata.put("preserved.register.source","SPRING_CLOUD");
            node.put("metadata",metadata);
            node.put("enabled",true);
            node.put("weight",1.0);
            node.put("clusterName","DEFAULT");
            node.put("serviceName",serviceName);
            node.put("ephemeral",true);
            hosts.add(node);
        }
        result.put("hosts",hosts);
        return result.toJSONString();
    }
    // http://127.0.0.1:8848/nacos/v1/ns/instance?serviceName=nacos.naming.serviceName&ip=20.18.7.10&port=8080
    @PostMapping("instance")
    public String list(@RequestParam("serviceName") String serviceName,@RequestParam("ip") String ip,@RequestParam("port") String port) throws ExecutionException, InterruptedException {
        //存etcd上
        String value=get(serviceName);
        if(value==null){
            JSONObject jsonObject=new JSONObject();
            List<String> ips=new ArrayList<>();
            List<String> ports=new ArrayList<>();
            ips.add(ip);
            ports.add(port);
            jsonObject.put("ips",ips);
            jsonObject.put("ports",ports);
            put(serviceName,jsonObject.toJSONString());
        }else{
            JSONObject jsonObject=JSONObject.parseObject(value);
            JSONArray ips = jsonObject.getJSONArray("ips");
            JSONArray ports = jsonObject.getJSONArray("ports");
            ips.add(ip);
            ports.add(port);
            jsonObject.put("ips",ips);
            jsonObject.put("ports",ports);
            put(serviceName,jsonObject.toJSONString());
        }
        return "ok";
    }
//127.0.0.1:8848/nacos/v1/ns/instance/beat?serviceName=nacos.test.2&
    // beat=%7b%22cluster%22%3a%22c1%22%2c%22ip%22%3a%22127.0.0.1%22%2c%22metadata%22%3a%7b%7d%2c%22port%22%3a8080%2c%22scheduled%22%3atrue%2c%22serviceName%22%3a%22jinhan0Fx4s.173TL.net%22%2c%22weight%22%3a1%7d'


    @PutMapping("instance/beat")
    public String beat(){
        return "{\"state\":\"ok\"}";
    }



    public static final String etcdAddress="http://127.0.0.1:2379";


    private static  void put(String key ,String value) throws ExecutionException, InterruptedException {
        Client client = Client.builder().endpoints(etcdAddress).build();
        ByteSequence byteKey = ByteSequence.from(key.getBytes());
        ByteSequence byteValue = ByteSequence.from(value.getBytes());
        client.getKVClient().put(byteKey, byteValue).get();

    }

    private static  String get(String key){
        Client client = Client.builder().endpoints(etcdAddress).build();
        ByteSequence byteKey = ByteSequence.from(key.getBytes());

        List<KeyValue> r=null;

        try {

            r=client.getKVClient().get(byteKey).get().getKvs();

        }catch (InterruptedException e) {

            e.printStackTrace();

        }catch (ExecutionException e) {

            e.printStackTrace();

        }
        String result=null;
        for (KeyValue kv : r) {

            //System.out.println(new String(kv.getKey().getBytes()));

            //System.out.println();
            result= new String(kv.getValue().getBytes());
        }
        client.close();
        return result;
    }


    public static void main(String[] args) throws Exception{
        put("name","zhangsan");
        System.out.println(get("name1")==null);
    }
}
